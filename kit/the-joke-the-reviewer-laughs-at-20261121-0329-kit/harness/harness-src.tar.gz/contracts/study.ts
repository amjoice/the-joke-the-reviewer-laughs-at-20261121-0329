// A study document: one authored page of figures and the words that state them, built by scripts/study/build.mjs from a
// spec and the fact registry, kept on the server as a generated module, and printed by three readers that must print the
// same words in the same order: the server's crawl body, the web app's page and the markdown twin (public-views.mdc).
//
//   StudyDoc              the document: its address, head, dateline and sections of blocks
//   StudyBlock            one block: a paragraph, a list, a note, a table of figures or an interval figure
//   studyPlainText        the document's words, one text run per line, in reading order: what every reader prints
//   renderStudyMarkdown   the document as markdown on an origin, in the same words and order
//
// Every figure in a document is already text here (formatted by the generator from a registry slot); the numbers beside
// some of them (`value`, `lo`, `hi`, a `scale`) only place marks on a drawn axis and are never printed by a reader.
// A leaf: no imports at all and no words of any one study, so the server and the web app both read it.

/** The ISO day (YYYY-MM-DD). */
export type StudyDay = string;

/** One figure placed on an axis: the text printed beside it, and the numbers that place it. */
export interface StudyMark {
  /** What the mark stands for, printed beside it. */
  readonly label: string;
  /** The figure as printed. */
  readonly text: string;
  /** Where the mark sits on the axis. */
  readonly value: number;
  /** The interval around it, when it has one (a whisker), and its two ends as printed. */
  readonly lo?: number;
  readonly hi?: number;
  readonly loText?: string;
  readonly hiText?: string;
  /** `hollow` draws an open marker: a figure shown for comparison, not the one the figure is about. */
  readonly style: 'solid' | 'hollow';
}

/** The extent of a drawn axis, in the figures' own units; `reference` is a line drawn across it (zero, an even chance). */
export interface StudyScale {
  readonly lo: number;
  readonly hi: number;
  readonly reference?: number;
}

/** One table column: its heading and the side its cells sit on (`end` for figures, which line up on their last digit). */
export interface StudyColumn {
  readonly label: string;
  readonly align: 'start' | 'end';
  /** Its cells carry an interval (`lo`, `hi`) a reader may draw as a whisker on the table's one `scale`. */
  readonly interval?: boolean;
}

/** One table cell: its text, and for a figure the numbers that place it on the table's scale. */
export interface StudyCell {
  readonly text: string;
  readonly value?: number;
  readonly lo?: number;
  readonly hi?: number;
}

export type StudyBlock =
  | { readonly type: 'p'; readonly text: string }
  | { readonly type: 'ul'; readonly items: readonly string[] }
  /** An aside: a limit, a caveat, said once beside the text it qualifies. */
  | { readonly type: 'note'; readonly text: string }
  /** A table; its caption is printed under it. `scale` is present when a column carries intervals. */
  | {
      readonly type: 'table';
      readonly columns: readonly StudyColumn[];
      readonly rows: readonly (readonly StudyCell[])[];
      readonly caption: string;
      readonly scale?: StudyScale;
    }
  /**
   * An interval figure: marks on one axis (`axis` names its unit), drawn as an image whose accessible label is the
   * caption; the caption is printed under it.
   */
  | {
      readonly type: 'interval';
      readonly axis: string;
      readonly marks: readonly StudyMark[];
      readonly scale: StudyScale;
      readonly caption: string;
    };

export interface StudySection {
  /** The section's anchor (lower-case words joined by hyphens). */
  readonly id: string;
  readonly heading: string;
  readonly blocks: readonly StudyBlock[];
}

export interface StudyDoc {
  /** The page's address on the site ('/research/...'). */
  readonly path: string;
  /** The head's title and description: no digit, so a link preview carries no figure. */
  readonly title: string;
  readonly description: string;
  /** The word above the title. */
  readonly kicker: string;
  /** The claim, under the title. */
  readonly lede: string;
  /** The line under the lede naming the day the figures were read and the day the page last changed. */
  readonly dateline: string;
  /** The newest as-of among the facts the document prints (an ISO date or time, as the registry holds it). */
  readonly as_of: string;
  /** The later of that day and the day the words last changed. */
  readonly updated: StudyDay;
  readonly sections: readonly StudySection[];
}

/** One block's text runs, in reading order. */
function blockRuns(b: StudyBlock): string[] {
  switch (b.type) {
    case 'p':
    case 'note':
      return [b.text];
    case 'ul':
      return [...b.items];
    case 'table':
      return [...b.columns.map((c) => c.label), ...b.rows.flatMap((r) => r.map((c) => c.text)), b.caption];
    case 'interval':
      return [
        ...b.marks.flatMap((m) => [m.label, m.text, ...(m.loText === undefined ? [] : [m.loText]), ...(m.hiText === undefined ? [] : [m.hiText])]),
        b.axis,
        b.caption,
      ];
  }
}

/**
 * The document's words: one text run per line, in reading order: the kicker, the title, the lede, the dateline, then
 * each section's heading and its blocks (a list item by item; a table's headings, its cells row by row, then its
 * caption; an interval figure's marks, each its label, its figure and its interval's two ends, then the axis's unit
 * and the caption). A reader prints exactly these runs, in this order; a comparison collapses whitespace.
 */
export function studyPlainText(doc: StudyDoc): string {
  const runs = [doc.kicker, doc.title, doc.lede, doc.dateline];
  for (const s of doc.sections) runs.push(s.heading, ...s.blocks.flatMap(blockRuns));
  return runs.join('\n');
}

/** Words in markdown: only what markdown would read as more than text is escaped. */
const mdWords = (s: string): string => s.replace(/[\\`*_[\]<|]/g, '\\$&');
/** A block's first line: a leading mark markdown would read as a heading, a list or a quote is escaped too. */
const mdLine = (s: string): string => {
  const w = mdWords(s);
  return /^[#>+-](?=\s|$)/.test(w) ? `\\${w}` : w.replace(/^(\d+)([.)])(?=\s|$)/, '$1\\$2');
};

function blockMd(b: StudyBlock): string[] {
  switch (b.type) {
    case 'p':
      return [mdLine(b.text)];
    case 'note':
      return [`> ${mdWords(b.text)}`];
    case 'ul':
      return b.items.map((i) => `- ${mdWords(i)}`);
    case 'table': {
      const row = (cells: readonly string[]): string => `| ${cells.join(' | ')} |`;
      return [
        row(b.columns.map((c) => mdWords(c.label))),
        row(b.columns.map((c) => (c.align === 'end' ? '---:' : '---'))),
        ...b.rows.map((r) => row(r.map((c) => mdWords(c.text)))),
        '',
        mdLine(b.caption),
      ];
    }
    case 'interval':
      return [
        ...b.marks.map((m) => `- ${mdWords([m.label, m.text, ...(m.loText === undefined ? [] : [m.loText]), ...(m.hiText === undefined ? [] : [m.hiText])].join(' '))}`),
        '',
        mdLine(b.axis),
        '',
        mdLine(b.caption),
      ];
  }
}

/**
 * The document as markdown (the address's twin, answered to Accept: text/markdown and ?format=md): the same runs as
 * studyPlainText in the same order, the title as the one H1 and each section's heading an H2, a table as a pipe table
 * with its caption under it, an interval figure's marks as a list; then the page's own address on `origin`.
 */
export function renderStudyMarkdown(doc: StudyDoc, origin: string): string {
  const out = [mdLine(doc.kicker), '', `# ${mdWords(doc.title)}`, '', mdLine(doc.lede), '', mdLine(doc.dateline)];
  for (const s of doc.sections) {
    out.push('', `## ${mdWords(s.heading)}`);
    for (const b of s.blocks) out.push('', ...blockMd(b));
  }
  out.push('', `<${origin.replace(/\/+$/, '')}${doc.path}>`, '');
  return out.join('\n');
}
